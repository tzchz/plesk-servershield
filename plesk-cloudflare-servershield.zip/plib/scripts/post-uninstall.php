<?php
	pm_Scheduler::getInstance()->removeAllTasks();